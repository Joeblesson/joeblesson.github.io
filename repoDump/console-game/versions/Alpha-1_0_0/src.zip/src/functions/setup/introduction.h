#include <iostream>

void playIntro() {
    system("cls");
    std::cout << "Hello...\n\n";
    std::cout << "[Press any key to continue]\n";
    std::cin.ignore();
    system("cls");
    std::cout << "Hello...\n";
    std::cout << "Test\n\n";
    std::cout << "[Press any key to continue]\n";
    std::cin.ignore();
    system("cls");
    
    
}