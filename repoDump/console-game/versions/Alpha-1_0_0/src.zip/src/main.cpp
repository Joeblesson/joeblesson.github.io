#include "functions/includeAll.h"

int main() {
    playIntro();
}