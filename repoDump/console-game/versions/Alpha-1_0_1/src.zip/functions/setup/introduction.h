#include <iostream>

void first() {
    system("cls");
    std::cout << "Hello...\n\n";
    std::cout << "[Press Enter to continue]\n";
    std::cin.ignore();
    system("cls");
    std::cout << "Hello...\n";
    std::cout << "You are in a console game\n\n";
    std::cout << "[Press Enter to continue]\n";
    std::cin.ignore();
    system("cls");
    std::cout << "Hello...\n";
    std::cout << "You are in a console game\n";
    std::cout << "It will be like an rpg or something idk\n\n";
    std::cout << "[Press Enter to continue]\n";
    std::cin.ignore();
    system("cls");
    std::cout << "Hello...\n";
    std::cout << "You are in a console game\n";
    std::cout << "It will be like an rpg or something idk\n";
    std::cout << "Whatever just play it\n\n";
    std::cout << "[Press Enter to continue]\n";
    std::cin.ignore();
    system("cls");
}