#include <iostream>

void usrSetup() {
    
}