#include <iostream>
#include <string>

using std::string;

void playIntro() {
    string line1 = "IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII";
    string line2 = "IIIIIGGGGGGGGGGIIIIIIIIIIIIIIIIIIIIIAAAAAAAAAAAAAAIIIIIIIIIIIIIIIMMMMMMMMMIIIIIIIIMMMMMMMMMIIIIIIIIEEEEEEEEEEEEEEEEEEEEEEIIII";
    string line3 = "IIIIGGGGGGGGGGGIIIIIIIIIIIIIIIIIIIIAAAAAAAAAAAAAAAAIIIIIIIIIIIIIIMMMMIIMMMMIIIIIIMMMMIIMMMMIIIIIIIIEEEEEEEEEEEEEEEEEEEEEEIIII";
    string line4 = "IIIGGGIIIIIIIIIIIIIIIIIIIIIIIIIIIIAAAAIIIIIIIIIIAAAAIIIIIIIIIIIIIMMMMIIIMMMMIIIIMMMMIIIMMMMIIIIIIIIEEEEIIIIIIIIIIIIIIIIIIIIII";
    string line5 = "IIIGGGIIIIIIIIIIIIIIIIIIIIIIIIIIIIAAAAIIIIIIIIIIAAAAIIIIIIIIIIIIIMMMMIIIIMMMMIIMMMMIIIIMMMMIIIIIIIIEEEEIIIIIIIIIIIIIIIIIIIIII";
    string line6 = "IIIGGGIIIIIIIIIGGGGGGGIIIIIIIIIIIAAAAIIIIIIIIIIIIAAAAIIIIIIIIIIIIMMMMIIIIIMMMMMMMMIIIIIMMMMIIIIIIIIEEEEEEEEEEEEEEIIIIIIIIIIII";
    string line7 = "IIIGGGIIIIIIIIIIGGGGGGGIIIIIIIIIAAAAAAAAAAAAAAAAAAAAAAIIIIIIIIIIIMMMMIIIIIIMMMMMMIIIIIIMMMMIIIIIIIIEEEEEEEEEEEEEEIIIIIIIIIIII";
    string line8 = "IIIGGGIIIIIIIIIIIIIGGGGGIIIIIIIIAAAAAAAAAAAAAAAAAAAAAAIIIIIIIIIIIMMMMIIIIIIIIIIIIIIIIIIMMMMIIIIIIIIEEEEIIIIIIIIIIIIIIIIIIIIII";
    string line9 = "IIIGGGIIIIIIIIIIIIIGGGGIIIIIIIIIAAAAIIIIIIIIIIIIIIAAAAIIIIIIIIIIIMMMMIIIIIIIIIIIIIIIIIIMMMMIIIIIIIIEEEEIIIIIIIIIIIIIIIIIIIIII";
    string lin10 = "IIIIGGGGGGGGGGGGGGGGGGGIIIIIIIIIAAAAIIIIIIIIIIIIIIAAAAIIIIIIIIIIIMMMMIIIIIIIIIIIIIIIIIIMMMMIIIIIIIIEEEEEEEEEEEEEEEEEEEEEEIIII";
    string lin11 = "IIIIIIGGGGGGGGGGGGGGIIIIIIIIIIIIAAAAIIIIIIIIIIIIIIAAAAIIIIIIIIIIIMMMMIIIIIIIIIIIIIIIIIIMMMMIIIIIIIIEEEEEEEEEEEEEEEEEEEEEEIIII";
    string lin12 = "IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII";

    _sleep(100);
    std::cout << line1 << "\n";
    _sleep(100);
    std::cout << line2 << "\n";
    _sleep(100);
    std::cout << line3 << "\n";
    _sleep(100);
    std::cout << line4 << "\n";
    _sleep(100);
    std::cout << line5 << "\n";
    _sleep(100);
    std::cout << line6 << "\n";
    _sleep(100);
    std::cout << line7 << "\n";
    _sleep(100);
    std::cout << line8 << "\n";
    _sleep(100);
    std::cout << line9 << "\n";
    _sleep(100);
    std::cout << lin10 << "\n";
    _sleep(100);
    std::cout << lin11 << "\n";
    _sleep(100);
    std::cout << lin12 << "\n";
    _sleep(200);
    for (int i = 0; i <= 124; i++) {
        line1.pop_back();
        std::cout << line1 << "\n";
        _sleep(0.001);
        line2.pop_back();
        std::cout << line2 << "\n";
        _sleep(0.001);
        line3.pop_back();
        std::cout << line3 << "\n";
        _sleep(0.001);
        line4.pop_back();
        std::cout << line4 << "\n";
        _sleep(0.001);
        line5.pop_back();
        std::cout << line5 << "\n";
        _sleep(0.001);
        line6.pop_back();
        std::cout << line6 << "\n";
        _sleep(0.001);
        line7.pop_back();
        std::cout << line7 << "\n";
        _sleep(0.001);
        line8.pop_back();
        std::cout << line8 << "\n";
        _sleep(0.001);
        line9.pop_back();
        std::cout << line9 << "\n";
        _sleep(0.001);
        lin10.pop_back();
        std::cout << lin10 << "\n";
        _sleep(0.001);
        lin11.pop_back();
        std::cout << lin11 << "\n";
        _sleep(0.001);
        lin12.pop_back();
        std::cout << lin12 << "\n";
        _sleep(0.001);
    }
    system("cls");
    std::cout << "Made by Joeblesson\n";
    std::cin.ignore();
    system("cls");
}