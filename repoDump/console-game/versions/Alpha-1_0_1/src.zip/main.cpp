#include "functions/includeAll.h"

int main() {
    first();
    playIntro();
    usrSetup();
}